<?php

$host = "localhost";
$dbname = "assistencia_social"; 
$user = "root";
$pass = "";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8",
        $user,
        $pass
    );

    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

} catch(PDOException $e){
    // Se der erro, avisa que é JSON, cospe o erro e PARA a execução.
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode([
        "status" => false,
        "mensagem" => "Erro de conexão com o banco de dados: " . $e->getMessage()
    ]);
    exit; // Impede que o resto do sistema tente rodar sem banco
}
?>