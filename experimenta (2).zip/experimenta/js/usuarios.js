// URL base da sua API PHP
const API_URL = 'api.php';

// ==========================================
// FUNÇÃO: Carregar Usuários na Tabela (GET)
// ==========================================
async function carregarUsuarios() {
    const tbody = document.getElementById('tabelaUsuariosBody');
    if (!tbody) return;
    
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-gray-500 py-4"><i class="fas fa-spinner fa-spin mr-2"></i>Carregando dados do banco...</td></tr>';

    try {
        // Faz a conexão GET simples para listar todos
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error('Erro na resposta do servidor.');

        const usuarios = await response.json();
        tbody.innerHTML = '';

        if (usuarios.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-gray-600 py-4">Nenhum usuário cadastrado.</td></tr>';
            return;
        }

        usuarios.forEach(usuario => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="align-middle">${usuario.cpf || 'Não informado'}</td>
                <td class="align-middle">${usuario.num_nis || 'Não informado'}</td>
                <td class="align-middle">${usuario.num_cad_unico || 'Não informado'}</td>
                <td class="align-middle">${usuario.nome} ${usuario.sobrenome || ''}</td>
                <td class="align-middle">${usuario.cep || 'Não informado'}</td>
                <td class="text-center align-middle">
                    <button onclick="alterarUsuario(${usuario.id})" class="btn btn-warning btn-sm btn-icon-split mb-1 mt-1">
                        <span class="icon text-white-50"><i class="fas fa-pen"></i></span>
                        <span class="text">Alterar</span>
                    </button>
                    <button onclick="excluirUsuario(${usuario.id})" class="btn btn-danger btn-sm btn-icon-split mb-1 mt-1">
                        <span class="icon text-white-50"><i class="fas fa-times"></i></span>
                        <span class="text">Desativar</span>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });

    } catch (error) {
        console.error("Erro ao listar:", error);
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-danger py-4"><i class="fas fa-exclamation-triangle mr-2"></i>Erro ao carregar dados da rede local.</td></tr>';
    }
}

// ==========================================
// FUNÇÃO: Enviar os dados para o Banco (POST)
// ==========================================
async function salvarDados() {
    // Fecha o modal de confirmação visual
    $('#popupConfirmacao').modal('hide');

    if (!dadosPendentes) return;

    // Prepara os dados no formato FormData para o PHP ler via $_POST
    const formData = new FormData();
    formData.append('num_nis', dadosPendentes.nis || '');
    formData.append('num_cad', dadosPendentes.cad || ''); // mapeia para num_cad_unico na API
    formData.append('nome', dadosPendentes.nome);
    formData.append('sobrenome', dadosPendentes.sobrenome);
    formData.append('cpf', dadosPendentes.cpf || '');
    formData.append('rg', dadosPendentes.rg || '');
    formData.append('nascimento', dadosPendentes.nascimento || '');
    formData.append('cep', dadosPendentes.cep || '');
    formData.append('sexo', 'Não informado'); // Campo padrão exigido pela sua API

    try {
        // Envia os dados via POST com o parâmetro 'action' na URL da API
        const response = await fetch(`${API_URL}?action=cadastrar`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error('Erro ao salvar os dados.');

        const resultado = await response.json();

        if (resultado.status) {
            mostrarPopup('sucesso', dadosPendentes);
            dadosPendentes = null;
            limparCampos();
            
            // Fecha o modal de cadastro e recarrega a tabela de usuários atualizada
            $('#addUserModal').modal('hide');
            carregarUsuarios();
        } else {
            mostrarPopup('erro', null, resultado.erro || 'Falha interna no servidor.');
        }

    } catch (error) {
        console.error("Erro no cadastro:", error);
        mostrarPopup('erro', null, 'Não foi possível estabelecer conexão com o servidor local.');
    }
}

// Funções auxiliares para leitura de formulário
function getValor(id) {
    const campo = document.getElementById(id);
    if (!campo || campo.getAttribute('data-naoinformado') === 'true') return null;
    return campo.value.trim() || null;
}

let dadosPendentes = null;

function confirmarDados() {
    const dados = {
        nome:        getValor('inputNome'),
        sobrenome:   getValor('inputSobrenome'),
        cpf:         getValor('inputCPF'),
        rg:          getValor('inputRG'),
        nascimento:  getValor('inputNascimento'),
        telefone:    getValor('inputTelefone'),
        cep:         getValor('inputCEP'),
        endereco:    getValor('inputEndereco'),
        numero:      getValor('inputNumero'),
        complemento: getValor('inputComplemento'),
        bairro:      getValor('inputBairro'),
        cidade:      getValor('inputCidade'),
        estado:      getValor('inputEstado'),
    };

    if (!dados.nome || !dados.sobrenome) {
        alert('Nome e Sobrenome são obrigatórios.');
        return;
    }

    const exibir = (valor) => valor ?? 'Não informado';

    document.getElementById('confirmacaoDados').innerHTML = `
        <hr>
        <p><strong>Nome:</strong> ${exibir(dados.nome)} ${exibir(dados.sobrenome)}</p>
        <p><strong>CPF:</strong> ${exibir(dados.cpf)}</p>
        <p><strong>RG:</strong> ${exibir(dados.rg)}</p>
        <p><strong>Nascimento:</strong> ${exibir(dados.nascimento)}</p>
        <hr>
        <p><strong>CEP:</strong> ${exibir(dados.cep)}</p>
        <p><strong>Endereço:</strong> ${exibir(dados.endereco)}, ${exibir(dados.numero)}</p>
        <hr>
    `;

    dadosPendentes = dados;
    $('#popupConfirmacao').modal('show');
}

function limparCampos() {
    const campos = ['inputNome', 'inputSobrenome', 'inputCPF', 'inputRG', 'inputNascimento', 'inputTelefone', 'inputCEP', 'inputEndereco', 'inputNumero', 'inputComplemento', 'inputBairro', 'inputCidade', 'inputEstado'];
    campos.forEach(id => {
        const elemento = document.getElementById(id);
        if (elemento) {
            elemento.value = '';
            elemento.disabled = false;
        }
    });
}

function mostrarPopup(tipo, dados, erroMsg) {
    const icone = document.getElementById('popupIcone');
    const titulo = document.getElementById('popupTitulo');
    const mensagem = document.getElementById('popupMensagem');

    // Criação dinâmica dos elementos caso seu modal use IDs padrão do Bootstrap
    alert(tipo === 'sucesso' ? "Operação realizada com sucesso!" : "Erro: " + erroMsg);
}

// Inicializa o evento do modal da tabela
document.addEventListener("DOMContentLoaded", () => {
    $('#usersTableModal').on('show.bs.modal', function () {
        carregarUsuarios();
    });
});