<?php 
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
// Permite tanto GET quanto POST
header("Access-Control-Allow-Methods: GET, POST"); 
session_start();

// O Caminho para a sua conexão
require_once("../config/db.php"); 

// Captura a ação, independente se veio por GET ou POST
$action = $_REQUEST['action'] ?? null; 

// ========================================================
// CAIXA 1: LISTAR TODOS OS USUÁRIOS (Sem action específica)
// ========================================================
if($_SERVER['REQUEST_METHOD'] == 'GET' && !$action){
    try {
        $sql = "SELECT * FROM usuarios ORDER BY nome ASC";
        $query = $pdo->prepare($sql);
        $query->execute();
        $usuarios = $query->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode($usuarios);
    } catch(PDOException $e) {
        echo json_encode(["status" => false, "erro" => $e->getMessage()]);
    }
    exit;
}

// ========================================================
// CAIXA 2: CADASTRAR USUÁRIO
// ========================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && $action == 'cadastrar'){
    
    // Tratamento correto de fallback em PHP
    $num_nis         = $_POST['num_nis'] ?? 'nao informado';
    $num_cad_unico   = $_POST['num_cad'] ?? 'nao informado';
    $nome            = $_POST['nome'] ?? 'nao informado';
    $sobrenome       = $_POST['sobrenome'] ?? 'nao informado'; // Corrigido o erro de digitação so;brenome
    $cpf             = $_POST['cpf'] ?? 'nao informado';
    $rg              = $_POST['rg'] ?? 'nao informado';
    $sexo            = $_POST['sexo'] ?? 'nao informado';
    $data_nascimento = $_POST['nascimento'] ?? 'nao informado';
    $cep             = $_POST['cep'] ?? 'nao informado';
    
    // Função correta para gerar data/hora atual no PHP
    $incluido_em     = date('Y-m-d H:i:s');
    $atualizado_em   = date('Y-m-d H:i:s');

    $sql = "INSERT INTO usuarios (num_nis, num_cad_unico, nome, sobrenome, cpf, rg, sexo, cep, data_nascimento, incluido_em, atualizado_em) 
            VALUES (:num_nis, :num_cad_unico, :nome, :sobrenome, :cpf, :rg, :sexo, :cep, :data_nascimento, :incluido_em, :atualizado_em)";

    try {
        $query = $pdo->prepare($sql);
        $query->bindParam(':num_nis', $num_nis);
        $query->bindParam(':num_cad_unico', $num_cad_unico);
        $query->bindParam(':nome', $nome);
        $query->bindParam(':sobrenome', $sobrenome);
        $query->bindParam(':cpf', $cpf);
        $query->bindParam(':rg', $rg);
        $query->bindParam(':sexo', $sexo);
        $query->bindParam(':data_nascimento', $data_nascimento);
        $query->bindParam(':cep', $cep);
        $query->bindParam(':incluido_em', $incluido_em);
        $query->bindParam(':atualizado_em', $atualizado_em);
        
        $query->execute();
        
        echo json_encode([
            "status" => true,
            "mensagem" => "Usuário cadastrado com sucesso"
        ]);
    } catch(PDOException $e) {
        echo json_encode(["status" => false, "erro" => $e->getMessage()]);
    }
    exit;
}

// ========================================================
// CAIXA 3: CONSULTAR UM USUÁRIO ESPECÍFICO (Por CPF)
// ========================================================
if($_SERVER['REQUEST_METHOD'] == 'GET' && $action == 'consultarUsuario'){
    try {
        // Limpa tudo que não for número do CPF
        $cpf = !empty($_GET['cpf']) ? preg_replace('/[^0-9]/', '', $_GET['cpf']) : null;

        if(!$cpf){
            echo json_encode(["status" => false, "mensagem" => "CPF não informado"]);
            exit;
        }

        $sql = "SELECT * FROM usuarios WHERE cpf = :cpf LIMIT 1";
        $query = $pdo->prepare($sql);
        $query->bindParam(':cpf', $cpf);
        $query->execute();
        
        $usuario = $query->fetch(PDO::FETCH_ASSOC);

        if($usuario){
            echo json_encode(["status" => true, "dados" => $usuario]);
        } else {
            echo json_encode(["status" => false, "mensagem" => "Usuário não encontrado"]);
        }

    } catch(PDOException $e) {
        echo json_encode(["status" => false, "erro" => $e->getMessage()]);
    }
    exit;
}
?>