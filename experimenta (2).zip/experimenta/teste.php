<?php
    echo 'teste';
?>

