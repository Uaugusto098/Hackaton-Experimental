<?php

header("Content-Type: application/json; charset=UTF-8");

$host = "localhost";
$dbname = "assistencia_social";
$user = "root";
$pass = "";

try {

    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8",
        $user,
        $pass
    );

    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

} catch(PDOException $e){

    echo json_encode([
        "erro" => true,
        "mensagem" => $e->getMessage()
    ]);

}