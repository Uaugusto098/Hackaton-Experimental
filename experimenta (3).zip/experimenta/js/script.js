
const api = 'http://10.100.152.150/template-experimenta/experimenta/querys/api.php'

const envio = async (methodApp = '',actionApp='',dados='') => {
    const action  = actionApp ? `?action=${actionApp}`:''
    const form = FormData();
    if(Array(dados)){
        dados.map((items)=>{
            form.append(items.name,items.value)
        })
    }
    form.append('')
    const env = await fetch(`${api}${action}`,{
        method:methodApp
    })

    const res = await env.json()

    console.log(res)

    return res
}

const container = document.querySelector('#container-body')


const carregarTabela = async () => {



    if(container){

        const data = await envio('GET')

        const spinner = document.createElement("div")
        spinner.innerHTML = `
        <div class="spinner-border" style="height:100px; width:100px; role="status">
            <span class="visually-hidden"></span>
        </div>
        `

        container.appendChild(spinner)

        
        
        const table = document.createElement('div')

        let usuarios = data.dados.map((usuario) => {

            return `
                <tr>
                    <td>${usuario.num_nis}</td>
                    <td>${usuario.num_cad_unico}</td>
                    <td>${usuario.nome} ${usuario.sobrenome}</td>
                    <td>${usuario.cpf}</td>
                    <td>${usuario.rg}</td>
                    <td>${usuario.sexo}</td>
                    <td>${usuario.data_nascimento}</td>
                    <td>${usuario.cep}</td>
                </tr>
            `
        }).join('')

        table.innerHTML = `
        <div class="container-fluid p-0 custom-card">
            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle m-0">

                    <thead>
                        <tr>
                            <th>NIS</th>
                            <th>Cad_único</th>
                            <th>Nome</th>
                            <th>CPF</th>
                            <th>RG</th>
                            <th>Sexo</th>
                            <th>Nascimento</th>
                            <th>CEP</th>
                        </tr>
                    </thead>

                    <tbody>
                        ${usuarios}
                    </tbody>

                </table>
            </div>

        </div>
        `

        container.innerHTML = ''

        container.appendChild(table)
    }
}

const servicosCard = async()=>{

    const data = await envio('GET','servicoCard')

    let cardContainer = document.createElement('div')
    
     cardContainer.classList.add(
        'row',
        'mx-4',
        'justify-content-center',
        'align-items-start',
        'gap'



     )

    const card = data.dados.map((servicos)=>{
        const status = servicos.status_serv ? 'ativo':'desabilitado'
        const btnClass = !servicos.status_serv ? 'btn-danger':'btn-success'
        const btnDisabled = !servicos.status_serv ? 'disabled':''
        
        return `
           <div class="card col-3 mx-2" style="width: 18rem; height:max-content;">
            <img src="" class="card-img-top" alt="...">
            <div class="card-body p-3">
                <h5 class="card-title">${servicos.descricao}</h5>
                <a href="#" style="font-size:.9rem; " class="p-1  btn small ${btnClass}" ${btnDisabled}>${status}</a>
                <button class="btn btn-primary mt-1" style="font-size:.8rem" >buscar atendimento</button>
            </div>
            </div>
        `    


    }).join('')
    cardContainer.innerHTML = card

    container.appendChild(cardContainer)




}
servicosCard()

// carregarTabela()





