<?php

/*
=========================================================
HEADERS
=========================================================
*/

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST");


/*
=========================================================
CONEXÃO
=========================================================
*/

require_once("../config/db.php");


/*
=========================================================
FUNÇÃO JSON
=========================================================
*/

function resposta($status, $dados){

    echo json_encode([
        "status" => $status,
        "dados" => $dados
    ]);

    exit;

}



/*
=========================================================
LISTAR USUÁRIOS
=========================================================

GET
/api.php

=========================================================
*/

if($_SERVER['REQUEST_METHOD'] == 'GET' && !isset($_GET['action'])){

    try{

        $sql = "
        SELECT
            *
        FROM usuarios
        ORDER BY nome ASC
        ";

        $query = $pdo->prepare($sql);

        $query->execute();

        $usuarios = $query->fetchAll(PDO::FETCH_ASSOC);

        resposta(true, $usuarios);

    }catch(PDOException $e){

        resposta(false, $e->getMessage());

    }

}
if($_SERVER['REQUEST_METHOD'] == 'GET' && !isset($_GET['action'])){

    try{

        $sql = "
        SELECT
            *
        FROM usuarios
        ORDER BY nome ASC
        ";

        $query = $pdo->prepare($sql);

        $query->execute();

        $usuarios = $query->fetchAll(PDO::FETCH_ASSOC);

        resposta(true, $usuarios);

    }catch(PDOException $e){

        resposta(false, $e->getMessage());

    }

}



/*
=========================================================
CONSULTAR USUÁRIO POR CPF
=========================================================

GET
/api.php?action=consultarUsuario&cpf=11111111111

=========================================================
*/

if(
    $_SERVER['REQUEST_METHOD'] == 'GET'
    &&
    isset($_GET['action'])
    &&
    $_GET['action'] == 'consultarUsuario'
){

    try{

        /*
        ============================================
        CPF
        ============================================
        */

        $cpf = !empty($_GET['cpf'])
            ? preg_replace('/[^0-9]/', '', $_GET['cpf'])
            : null;


        /*
        ============================================
        VALIDA CPF
        ============================================
        */

        if(!$cpf){

            resposta(false, "CPF não informado");

        }


        /*
        ============================================
        SQL
        ============================================
        */

        $sql = "
        SELECT
            *
        FROM usuarios
        WHERE cpf = :cpf
        LIMIT 1
        ";


        /*
        ============================================
        PREPARE
        ============================================
        */

        $query = $pdo->prepare($sql);


        /*
        ============================================
        BIND
        ============================================
        */

        $query->bindParam(':cpf', $cpf);


        /*
        ============================================
        EXECUTE
        ============================================
        */

        $query->execute();


        /*
        ============================================
        RESULTADO
        ============================================
        */

        $usuario = $query->fetch(PDO::FETCH_ASSOC);


        /*
        ============================================
        RETORNO
        ============================================
        */

        if($usuario){

            resposta(true, $usuario);

        }else{

            resposta(false, "Usuário não encontrado");

        }

    }catch(PDOException $e){

        resposta(false, $e->getMessage());

    }

}



/*
=========================================================
CADASTRAR USUÁRIO
=========================================================

POST
/api.php?action=cadastrar

=========================================================
*/

if(
    $_SERVER['REQUEST_METHOD'] == 'POST'
    &&
    isset($_GET['action'])
    &&
    $_GET['action'] == 'cadastrar'
){

    try{

        /*
        ============================================
        RECEBENDO DADOS
        ============================================
        */

        $num_nis = !empty($_POST['num_nis'])
            ? $_POST['num_nis']
            : 'NAO_INFORMADO';

        $num_cad_unico = !empty($_POST['num_cad_unico'])
            ? $_POST['num_cad_unico']
            : 'NAO_INFORMADO';

        $nome = !empty($_POST['nome'])
            ? $_POST['nome']
            : 'NAO_INFORMADO';

        $sobrenome = !empty($_POST['sobrenome'])
            ? $_POST['sobrenome']
            : 'NAO_INFORMADO';

        $cpf = !empty($_POST['cpf'])
            ? preg_replace('/[^0-9]/', '', $_POST['cpf'])
            : NULL;

        $rg = !empty($_POST['rg'])
            ? preg_replace('/[^0-9]/', '', $_POST['rg'])
            : 'NAO_INFORMADO';

        $sexo = !empty($_POST['sexo'])
            ? $_POST['sexo']
            : 'NAO_INFORMADO';

        $data_nascimento = !empty($_POST['data_nascimento'])
            ? $_POST['data_nascimento']
            : '2000-01-01';

        $cep = !empty($_POST['cep'])
            ? preg_replace('/[^0-9]/', '', $_POST['cep'])
            : '00000000';

        $incluido_em = date('Y-m-d H:i:s');

        $atualizado_em = date('Y-m-d H:i:s');



        /*
        ============================================
        SQL
        ============================================
        */

        $sql = "
        INSERT INTO usuarios
        (
            num_nis,
            num_cad_unico,
            nome,
            sobrenome,
            cpf,
            rg,
            sexo,
            data_nascimento,
            cep,
            incluido_em,
            atualizado_em
        )
        VALUES
        (
            :num_nis,
            :num_cad_unico,
            :nome,
            :sobrenome,
            :cpf,
            :rg,
            :sexo,
            :data_nascimento,
            :cep,
            :incluido_em,
            :atualizado_em
        )
        ";


        /*
        ============================================
        PREPARE
        ============================================
        */

        $query = $pdo->prepare($sql);


        /*
        ============================================
        BINDS
        ============================================
        */

        $query->bindParam(':num_nis', $num_nis);

        $query->bindParam(':num_cad_unico', $num_cad_unico);

        $query->bindParam(':nome', $nome);

        $query->bindParam(':sobrenome', $sobrenome);

        $query->bindParam(':cpf', $cpf);

        $query->bindParam(':rg', $rg);

        $query->bindParam(':sexo', $sexo);

        $query->bindParam(':data_nascimento', $data_nascimento);

        $query->bindParam(':cep', $cep);

        $query->bindParam(':incluido_em', $incluido_em);

        $query->bindParam(':atualizado_em', $atualizado_em);


        /*
        ============================================
        EXECUTA
        ============================================
        */

        $query->execute();


        /*
        ============================================
        RETORNO
        ============================================
        */

        resposta(true, "Usuário cadastrado com sucesso");



    }catch(PDOException $e){

        resposta(false, $e->getMessage());

    }

}

if(  $_SERVER['REQUEST_METHOD'] == 'GET'
    &&
    $_GET['action'] == 'servicoCard'){

    $sql = "
        SELECT
            *
        FROM servicos
        ";
    
    $query = $pdo->prepare($sql);
    $query->execute();

    $data = $query->fetchAll(PDO::FETCH_ASSOC);
    resposta(true,$data);

    }



/*
=========================================================
ROTA NÃO ENCONTRADA
=========================================================
*/

resposta(false, "Rota não encontrada");